/** 
 * File:   Lens.cpp
 * Author: hector
 */

#include "Lens.h"

Lens::Lens()
{

}

Lens::~Lens()
{

}
