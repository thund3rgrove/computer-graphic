/** 
 * File:   Toggler.cpp
 * Author: hector
 */

#include "Toggler.h"

Toggler::Toggler()
{

}

Toggler::~Toggler()
{

}

